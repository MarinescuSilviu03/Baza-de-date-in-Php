<?php
include("database.php");

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add'])) {
    $denumire_serie = $_POST['denumire_serie'];

    if (!preg_match("/^[a-zA-Z\s]+$/", $denumire_serie)) {
        echo "<div class='alert alert-danger'>Denumirea seriei poate conține doar litere și spații!</div>";
    } else {

    $numar_grupe = $_POST['numar_grupe'];
    $numar_studenti = $_POST['numar_studenti'];

    $query = "INSERT INTO serie (denumire_serie, numar_grupe, numar_studenti) VALUES ('$denumire_serie', '$numar_grupe', '$numar_studenti')";

    if (mysqli_query($conn, $query)) {
        echo "<div class='alert alert-success'>Serie adăugată cu succes!</div>";
    } else {
        echo "<div class='alert alert-danger'>Eroare la adăugare: " . mysqli_error($conn) . "</div>";
    }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Adaugă Serie</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card shadow-sm">
                    <div class="card-header text-center bg-primary text-white">
                        <h2>Adaugă Serie</h2>
                    </div>
                    <div class="card-body">
                        <form method="POST">
                            <div class="row">
                                <div class="mb-3">
                                    <label class="form-label">Denumire Serie</label>
                                    <input type="text" name="denumire_serie" class="form-control" required>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Număr Grupe</label>
                                    <input type="number" name="numar_grupe" class="form-control" required>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Număr Studenți</label>
                                    <input type="number" name="numar_studenti" class="form-control" required>
                                </div>

                                <div class="text-center">
                                    <button type="submit" name="add" class="btn btn-success w-50">Adaugă Serie</button>
                                    <a href="index.php" class="btn btn-secondary w-50 mt-2">Înapoi</a>
                                </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

</html>