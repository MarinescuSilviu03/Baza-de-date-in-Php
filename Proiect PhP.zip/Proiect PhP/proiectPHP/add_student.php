<?php
include("database.php");

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['create'])) {
    $nume = $_POST['nume'];
    $prenume = $_POST['prenume'];
    $adresa = $_POST['adresa'];
    $an_curent = $_POST['an_curent'];
    $cnp = $_POST['cnp'];
    $data_nastere = $_POST['data_nastere'];
    $idserie = $_POST['idserie'];
    $medie = $_POST['medie'];
    $numartelefon = $_POST['numartelefon'];

    if (!preg_match("/^[a-zA-Z\s]+$/", $nume)) 
    echo "<div class='alert alert-danger'>Numele studentului poate conține doar litere și spații!</div>";
    else if (!preg_match("/^[a-zA-Z-\s]+$/", $prenume))
    echo "<div class='alert alert-danger'>Prenumle studentului poate conține doar litere și spații!</div>";
    else if (!preg_match("/^[0-9\s]+$/", $cnp))
    echo "<div class='alert alert-danger'>Cnp-ul poate conține doar cifre!</div>";
    else  if (!preg_match("/^[0-9\s]+$/", $numartelefon))
    echo "<div class='alert alert-danger'>Numarul-ul de telefon poate conține doar cifre!</div>";
    else{
    $query = "INSERT INTO students (nume, prenume, adresa, an_curent, cnp, data_nastere, idserie, medie, numartelefon) 
              VALUES ('$nume', '$prenume', '$adresa', '$an_curent', '$cnp', '$data_nastere', '$idserie', '$medie', '$numartelefon')";

    if (mysqli_query($conn, $query)) {
        echo "<div class='alert alert-success'>Student adăugat cu succes!</div>";
    } else {
        echo "<div class='alert alert-danger'>Eroare la adăugare: " . mysqli_error($conn) . "</div>";
    }
}
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Adaugă Student</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card shadow-sm">
                    <div class="card-header text-center bg-primary text-white">
                        <h2>Adaugă Student</h2>
                    </div>
                    <div class="card-body">
                        <form method="POST">
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="nume" class="form-label">Nume</label>
                                    <input type="text" id="nume" name="nume" class="form-control" required>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="prenume" class="form-label">Prenume</label>
                                    <input type="text" id="prenume" name="prenume" class="form-control" required>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="adresa" class="form-label">Adresa</label>
                                    <input type="text" id="adresa" name="adresa" class="form-control" required>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="an_curent" class="form-label">An Curent</label>
                                    <input type="number" id="an_curent" name="an_curent" class="form-control" required>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="cnp" class="form-label">CNP</label>
                                    <input type="text" id="cnp" name="cnp" class="form-control" required>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="data_nastere" class="form-label">Data Naștere</label>
                                    <input type="date" id="data_nastere" name="data_nastere" class="form-control" required>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="idserie" class="form-label">ID Serie</label>
                                    <select id="idserie" name="idserie" class="form-select" required>
                                        <option value="" disabled selected>-- Selectați o serie --</option>
                                        <?php
                                        $serie_query = "SELECT idserie, denumire_serie FROM serie";
                                        $serie_result = mysqli_query($conn, $serie_query);

                                        while ($serie_row = mysqli_fetch_assoc($serie_result)) {
                                            echo "<option value='{$serie_row['idserie']}'>{$serie_row['denumire_serie']}</option>";
                                        }
                                        ?>
                                    </select>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="medie" class="form-label">Medie</label>
                                    <input type="number" id="medie" name="medie" step="0.01" class="form-control" required>
                                </div>
                            </div>
                            <div class="mb-3">
                                <label for="numartelefon" class="form-label">Număr Telefon</label>
                                <input type="text" id="numartelefon" name="numartelefon" class="form-control" required>
                            </div>
                            <div class="text-center">
                                <button type="submit" name="create" class="btn btn-success w-50">Adaugă Student</button>
                                <a href="index.php" class="btn btn-secondary w-50 mt-2">Înapoi</a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
