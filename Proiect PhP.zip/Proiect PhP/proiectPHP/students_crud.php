<?php
  include("database.php");

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['delete'])) {
    $idstudents = $_POST['idstudents'] ?? null;

    $query = "DELETE FROM students WHERE idstudents='$idstudents'";

    if (mysqli_query($conn, $query)) {
        echo "<div class='alert alert-success'>Student șters cu succes!</div>";
    } else {
        echo "<div class='alert alert-danger'>Eroare la ștergere: " . mysqli_error($conn) . "</div>";
    }
}
?>

<div class="container mt-5">
    <a href="add_student.php" class="btn btn-success mb-3">Adaugă Student</a>
    <table class="table table-bordered table-hover">
        <thead class="table-dark text-center">
            <tr>
                <th>ID</th>
                <th>Nume</th>
                <th>Prenume</th>
                <th>Adresa</th>
                <th>An Curent</th>
                <th>CNP</th>
                <th>Data Naștere</th>
                <th>Medie</th>
                <th>Număr Telefon</th>
                <th>Serie</th>
                <th>Acțiuni</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $query1 = "SELECT * FROM students";
            $result1 = mysqli_query($conn, $query1);
            $query2 = "SELECT denumire_serie FROM serie,students where serie.idserie=students.idserie;";
            $result2 = mysqli_query($conn, $query2);
            while ($row1 = mysqli_fetch_assoc($result1)) {
                $row2 = mysqli_fetch_assoc($result2);
                echo "<tr class='align-middle'>
                        <td class='text-center'>{$row1['idstudents']}</td>
                        <td class='text-center'>{$row1['nume']}</td>
                        <td class='text-center'>{$row1['prenume']}</td>
                        <td class='text-center'>{$row1['adresa']}</td>
                        <td class='text-center'>{$row1['an_curent']}</td>
                        <td class='text-center'>{$row1['cnp']}</td>
                        <td class='text-center'>{$row1['data_nastere']}</td>
                        <td class='text-center'>{$row1['medie']}</td>
                        <td class='text-center'>{$row1['numartelefon']}</td>
                        <td class='text-center'>{$row2['denumire_serie']}</td>
                        <td class='text-center'>
                            <div class='d-flex justify-content-center gap-2'>
                                <a href='edit_student.php?id={$row1['idstudents']}' class='btn btn-primary btn-sm'>Editează</a>
                                <form method='POST'>
                                    <input type='hidden' name='idstudents' value='{$row1['idstudents']}'>
                                    <button type='submit' name='delete' class='btn btn-danger btn-sm'>Șterge</button>
                                </form>
                            </div>
                        </td>
                      </tr>";
            }
            ?>
        </tbody>
    </table>
</div>

