<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Faculty</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h1 class="text-center">Facultatea de Electronică, Telecomunicații și Tehnologia Informației</h1>
        <ul class="nav nav-tabs mt-4">
            <li class="nav-item">
                <a class="nav-link active" href="#students" data-bs-toggle="tab">Students</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#series" data-bs-toggle="tab">Series</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#subjects" data-bs-toggle="tab">Subjects</a>
            </li>
        </ul>

        <div class="tab-content mt-4">
            <div class="tab-pane fade show active" id="students">
                <h2>Students</h2>
                <?php include ("students_crud.php"); ?>
            </div>
            <div class="tab-pane fade" id="series">
                <h2>Series</h2>
                <?php include ("serie_crud.php"); ?>
            </div>
            <div class="tab-pane fade" id="subjects">
                <h2>Subjects</h2>
                <?php include ("subjects_crud.php"); ?>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>