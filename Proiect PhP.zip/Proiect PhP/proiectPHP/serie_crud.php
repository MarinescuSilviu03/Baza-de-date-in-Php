<?php
include("database.php");

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['delete'])) {
    $idserie = $_POST['idserie'] ?? null;

    $query = "DELETE FROM serie WHERE idserie='$idserie'";

    if (mysqli_query($conn, $query)) {
        echo "<div class='alert alert-success'>Serie ștearsă cu succes!</div>";
    } else {
        echo "<div class='alert alert-danger'>Eroare la ștergere: " . mysqli_error($conn) . "</div>";
    }
}
?>

<div class="container mt-5">
    <a href="add_serie.php" class="btn btn-success mb-3">Adaugă Serie</a>
    <table class="table table-bordered table-hover">
        <thead class="table-dark text-center">
            <tr>
                <th>ID Serie</th>
                <th>Nume Serie</th>
                <th>Numar grupe</th>
                <th>Numar studenti</th>
                <th>Acțiuni</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $query = "SELECT * FROM serie";
            $result = mysqli_query($conn, $query);

            while ($row = mysqli_fetch_assoc($result)) {
                echo "<tr class='align-middle'>
                        <td class='text-center'>{$row['idserie']}</td>
                        <td class='text-center'>{$row['denumire_serie']}</td>
                        <td class='text-center'>{$row['numar_grupe']}</td>
                        <td class='text-center'>{$row['numar_studenti']}</td>
                        <td class='text-center'>
                            <div class='d-flex justify-content-center gap-2'>
                                <a href='edit_serie.php?id={$row['idserie']}' class='btn btn-primary btn-sm'>Editează</a>
                                <form method='POST'>
                                    <input type='hidden' name='idserie' value='{$row['idserie']}'>
                                    <button type='submit' name='delete' class='btn btn-danger btn-sm'>Șterge</button>
                                </form>
                            </div>
                        </td>
                      </tr>";
            }
            ?>
        </tbody>
    </table>
</div>
