<?php
include("database.php");

$idsubjects = $_GET['id'];
$query = "SELECT * FROM subjects WHERE idsubjects='$idsubjects'";
$result = mysqli_query($conn, $query);
$subject = mysqli_fetch_assoc($result);

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update'])) {
    $denumire_subject = $_POST['denumire_subject'];
    $an_predare = $_POST['an_predare'];
    $semestru_predare = $_POST['semestru_predare'];
    $puncte_credit = $_POST['puncte_credit'];
    $profesor = $_POST['profesor'];
    $idserie = $_POST['idserie'];

    if (!preg_match("/^[a-zA-Z\s]+$/", $denumire_subject)) 
        echo "<div class='alert alert-danger'>Denumirea subiectului poate conține doar litere și spații!</div>";
        else if (!preg_match("/^[a-zA-Z\s]+$/", $profesor))
        echo "<div class='alert alert-danger'>Numele profesorului poate conține doar litere și spații!</div>";
     else {
    $query = "UPDATE subjects 
              SET denumire_subject='$denumire_subject', an_predare='$an_predare', semestru_predare='$semestru_predare', 
                  puncte_credit='$puncte_credit', profesor='$profesor', idserie='$idserie' 
              WHERE idsubjects='$idsubjects'";

    if (mysqli_query($conn, $query)) {
        echo "<div class='alert alert-success'>Subiect actualizat cu succes!</div>";
    } else {
        echo "<div class='alert alert-danger'>Eroare la actualizare: " . mysqli_error($conn) . "</div>";
    }
}
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editează Subiect</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card shadow-sm">
                    <div class="card-header text-center bg-primary text-white">
                        <h2>Editează Subiect</h2>
                    </div>
                    <div class="card-body">
                        <form method="POST">
                            <div class="mb-3">
                                <label for="denumire_subject" class="form-label">Denumire Subiect</label>
                                <input type="text" id="denumire_subject" name="denumire_subject" class="form-control" value="<?= htmlspecialchars($subject['denumire_subject']) ?>" required>
                            </div>
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="an_predare" class="form-label">An Predare</label>
                                    <input type="number" id="an_predare" name="an_predare" class="form-control" value="<?= htmlspecialchars($subject['an_predare']) ?>" required>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="semestru_predare" class="form-label">Semestru Predare</label>
                                    <input type="number" id="semestru_predare" name="semestru_predare" class="form-control" value="<?= htmlspecialchars($subject['semestru_predare']) ?>" required>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="puncte_credit" class="form-label">Puncte Credit</label>
                                    <input type="number" id="puncte_credit" name="puncte_credit" step="0.01" class="form-control" value="<?= htmlspecialchars($subject['puncte_credit']) ?>" required>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="profesor" class="form-label">Profesor</label>
                                    <input type="text" id="profesor" name="profesor" class="form-control" value="<?= htmlspecialchars($subject['profesor']) ?>" required>
                                </div>
                            </div>
                            <div class="mb-3">
                                <label for="idserie" class="form-label">Serie</label>
                                <select id="idserie" name="idserie" class="form-select" required>
                                    <?php
                                    $serie_query = "SELECT idserie, denumire_serie FROM serie";
                                    $serie_result = mysqli_query($conn, $serie_query);

                                    while ($serie_row = mysqli_fetch_assoc($serie_result)) {
                                        $selected = $serie_row['idserie'] == $subject['idserie'] ? "selected" : "";
                                        echo "<option value='{$serie_row['idserie']}' $selected>{$serie_row['denumire_serie']}</option>";
                                    }
                                    ?>
                                </select>
                            </div>
                            <div class="text-center">
                                <button type="submit" name="update" class="btn btn-primary w-50">Actualizează Subiect</button>
                                <a href="index.php" class="btn btn-secondary w-50 mt-2">Înapoi</a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>

