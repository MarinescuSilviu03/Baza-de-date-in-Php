<?php
include("database.php");

if (isset($_GET['id'])) {
    $idserie = $_GET['id'];


    $query = "SELECT * FROM serie WHERE idserie='$idserie'";
    $result = mysqli_query($conn, $query);
    $serie = mysqli_fetch_assoc($result);

    if (!$serie) {
        echo "<div class='alert alert-danger'>Serie nu a fost găsită!</div>";
        exit;
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update'])) {
    $denumire_serie = $_POST['denumire_serie'];

    if (!preg_match("/^[a-zA-Z\s]+$/", $denumire_serie)) {
        echo "<div class='alert alert-danger'>Denumirea seriei poate conține doar litere și spații!</div>";
    } else {
    $numar_grupe = $_POST['numar_grupe'];
    $numar_studenti = $_POST['numar_studenti'];

    $query = "UPDATE serie SET denumire_serie='$denumire_serie', numar_grupe='$numar_grupe', numar_studenti='$numar_studenti' WHERE idserie='$idserie'";

    if (mysqli_query($conn, $query)) {
        echo "<div class='alert alert-success'>Serie actualizată cu succes!</div>";
    } else {
        echo "<div class='alert alert-danger'>Eroare la actualizare: " . mysqli_error($conn) . "</div>";
    }
}
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editează Serie</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card shadow-sm">
                    <div class="card-header text-center bg-primary text-white">
                        <h2>Editează Serie</h2>
                    </div>
                    <div class="card-body">
                        <form method="POST">
                            <div class="row">
                                <div class="mb-3">
                                    <label class="form-label">Denumire Serie</label>
                                    <input type="text" name="denumire_serie" class="form-control" value="<?= $serie['denumire_serie'] ?>" required>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Număr Grupe</label>
                                    <input type="number" name="numar_grupe" class="form-control" value="<?= $serie['numar_grupe'] ?>" required>
                                </div>
                            </div>
                            <div class="row">
                                <div class="mb-3">
                                    <label class="form-label">Număr Studenți</label>
                                    <input type="number" name="numar_studenti" class="form-control" value="<?= $serie['numar_studenti'] ?>" required>
                                </div>

                            </div>

                            <div class="text-center">
                                <button type="submit" name="update" class="btn btn-primary w-50">Actualizează Serie</button>
                                <a href="index.php" class="btn btn-secondary w-50 mt-2">Înapoi</a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

</html>