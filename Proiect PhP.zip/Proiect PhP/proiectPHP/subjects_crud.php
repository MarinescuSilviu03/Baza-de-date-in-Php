<?php
include("database.php");

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['delete'])) {
    $idsubject = $_POST['idsubjects'] ?? null;

    $query = "DELETE FROM subjects WHERE idsubjects='$idsubject'";

    if (mysqli_query($conn, $query)) {
        echo "<div class='alert alert-success'>Subject șters cu succes!</div>";
    } else {
        echo "<div class='alert alert-danger'>Eroare la ștergere: " . mysqli_error($conn) . "</div>";
    }
}
?>

<div class="container mt-5">
    <a href="add_subject.php" class="btn btn-success mb-3">Adaugă Subject</a>
    <table class="table table-bordered table-hover">
        <thead class="table-dark text-center">
            <tr>
                <th>ID</th>
                <th>Nume Materie</th>
                <th>An predare</th>
                <th>Semestru predare</th>
                <th>Credite</th>
                <th>Profesor</th>
                <th>Serie</th>
                <th>Acțiuni</th>
            </tr>
        </thead>
        <tbody>
            <?php
            // Interogare pentru afișarea materiilor
            $query1 = "SELECT * FROM subjects";
            $result1 = mysqli_query($conn, $query1);
            $query2 = "SELECT denumire_serie FROM serie,subjects where serie.idserie=subjects.idserie;";
            $result2 = mysqli_query($conn, $query2);
            while ($row1 = mysqli_fetch_assoc($result1)) {
                $row2 = mysqli_fetch_assoc($result2);
                echo "<tr class='align-middle'>
                        <td class='text-center'>{$row1['idsubjects']}</td>
                        <td class='text-center'>{$row1['denumire_subject']}</td>
                        <td class='text-center'>{$row1['an_predare']}</td>
                        <td class='text-center'>{$row1['semestru_predare']}</td>
                        <td class='text-center'>{$row1['puncte_credit']}</td>
                        <td class='text-center'>{$row1['profesor']}</td>
                        <td class='text-center'>{$row2['denumire_serie']}</td>
                        <td class='text-center'>
                            <div class='d-flex justify-content-center gap-2'>
                                <a href='edit_subject.php?id={$row1['idsubjects']}' class='btn btn-primary btn-sm'>Editează</a>
                                <form method='POST'>
                                    <input type='hidden' name='idsubjects' value='{$row1['idsubjects']}'>
                                    <button type='submit' name='delete' class='btn btn-danger btn-sm'>Șterge</button>
                                </form>
                            </div>
                        </td>
                      </tr>";
            }
            ?>
        </tbody>
    </table>
</div>
