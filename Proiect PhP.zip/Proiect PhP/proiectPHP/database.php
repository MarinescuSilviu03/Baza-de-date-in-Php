<?php
  $db_server="localhost";
  $db_user="root";
  $db_pass="12345";
  $db_name="proiect";

$conn=mysqli_connect($db_server,$db_user,$db_pass,$db_name); 
?>